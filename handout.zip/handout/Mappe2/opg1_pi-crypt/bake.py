base = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789æøåÆØÅ .,!?-:()[]/{}=<>+_@^|~%$#&*`“';"

with open('unbaked_pi.txt') as f:
    pie = f.read()

assert len(base) == 100 and len(pie) == 1000

def pie_crypt(text: str, key: str, decrypt: bool=False) -> str:
    out = ""
    i = sum(base.index(c) for c in key)
    j = 0

    for c in text:
        d1 = int(pie[i % len(pie)])
        i += base.index(key[j % len(key)])
        j += 1

        d2 = int(pie[i % len(pie)])
        i += base.index(key[j % len(key)])
        j += 1

        shift = 10 * d1 + d2
        out += base[(base.index(c) + (-shift if decrypt else shift)) % len(base)]

    return out


from secret import text, flag
assert all(c in base for c in text+flag) and flag[:8] + flag[-1] == 'brunner{}'

with open('baked_pie.txt', 'w', encoding="utf-8") as f:
    f.write(pie_crypt(text, flag))
