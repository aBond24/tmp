# π-crypt

**Difficulty:** Hard  
**Author:** Bond  

Recipe for 👨‍🍳 home made 😋 pie cipher:

* 100 char printable base 🥞
* 1k digits of pie 🥧
* 2-3k of blueberry plain-texture 🫐

And finally the key ingredient:

* 1 flagon of secret sauce 🏺

> **Recipe tip:** For the best result, use English blueberry plain-texture with standard punctuation.
