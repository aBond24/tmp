from nut_secure import *
#create_pepper() # e9d8
print(password_hash("Test123!")) # 8b56d663500f6f36f7b2f329cbcfe65851b146df3567e0b2fcf896391d641b7f

#(By the way also tested the following:
#validate_password(input("\nInput password:")) #)

users =  ["Alice", "Brunner", "Claude", "Dud", "Emul", "Frank"]  
passwords = ["gfedcba", "abcake", "nzbtg", "dud", "dud", "letmein"]

def create_psswrds():
    with open('psswrds.csv', 'w') as f: 
        f.write("user_name,password_hash")
        for i in range(6):
            ph = password_hash(passwords[i])
            f.write('\n' + users[i] + ',' + ph)
create_psswrds()


from peppernut_recipes import data
import os
#nonce = [os.urandom(12).hex() for _ in range(6)]
nonce = ['394acaf0e2550e2dc5bfacac', 'a21118815834c565eb17d095', '75399a35eff07a7f92a551d8', 'bd1251d5608613fc58dd0706', '0d571d6257db19acfece13a9', 'aa70d936155b272c869bac90']
#hash_salt = [os.urandom(16).hex() for _ in range(6)]
hash_salt = ['a85fa1f0edbb9afd0ac90f6439f52d88', '46dc4a82c159f9031169b7401238aacf', 'f3fd015d5459142a607b1c8d72a44036', 'a1df29bca0ae24fe6d656e1f55506ffd', 'e9dae11fe3da2593fd06b52e51a7c352', 'ecf6ec68a70f4ce7a9556b580793f3f2']
#key_salt = [os.urandom(16).hex() for _ in range(6)]
key_salt = ['2c8746070bd2ae310727efc0798d92ca', '86f27961fff1084639ce83c3f6e15f8f', 'acbb07a0b05ff5a1ffad512d6671b08a', '3f559ae3727f4205d0d85736a9c4f08e', '9b3caa6f26ce42607bd70ffa92e89a6d', '3a2c896c5469affa0f2fdc1e7cc2c01b']
cipher_data = [encrypted_data(data[i].encode('utf-8').hex(), nonce[i], passwords[i], hash_salt[i], key_salt[i]) for i in range(6)]

def create_peppernut_recipes():
    with open('peppernut_recipes.csv', 'w') as f:
        f.write("user_name,nonce,hash_salt,key_salt,encrypted_recipe")
        for i in range(6):
            f.write('\n' + users[i] + ',' + nonce[i] + ',' + hash_salt[i] + ',' + key_salt[i] + ',' + cipher_data[i])
create_peppernut_recipes()
