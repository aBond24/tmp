data = [
    """🍪 Alice’s Wonderland Pepper Nut Recipe 🍪

Ingredients:
•	3 curious teaspoons of pepper (black, white, or rainbow-hued — depending on what the Mad Hatter hands you)
•	1 cup of talking flour (it whispers riddles while you sift it)
•	2 spoons of sugar lumps that giggle when stirred
•	A pat of butter that melts into little question marks
•	A dash of nonsense (to taste)
•	Optional: a sprinkle of disappearing salt (vanishes if you look directly at it)
 
Instructions:

1️⃣ Consult the Cheshire Cat:
•	He may suggest you start at the beginning… or the end… or upside-down. Ignore him gently.

2️⃣ Mix Dry Ingredients:
•	Combine talking flour, sugar lumps, pepper, and disappearing salt in a bowl. If the sugar hums a tune, you’re on the right track.

3️⃣ Add Butter & Nonsense:
•	Fold in the butter while reciting a riddle to keep it from escaping. Stir in a dash of nonsense — the Queen of Hearts insists it makes the biscuits crisper.

4️⃣ Shape into Peculiar Forms:
•	Roll into small balls, or cut into shapes of keys, clocks, playing cards, or grinning cats.

5️⃣ Bake Until Curious:
•	Place in an oven heated precisely to “just before teapot boils” (approximately 180°C). Bake until they smell slightly mischievous and look golden around the edges.

6️⃣ Serve at a Mad Tea Party:
•	Best enjoyed among eccentric friends, with endless cups of tea and more questions than answers.
 
Notes:
•	If the White Rabbit arrives late, hide a few biscuits for him.
•	If the Queen of Hearts demands your recipe, offer her a riddle instead — it buys you time to sneak away with your treats.
""",
    "brunner{Maybe_we_could_mould_some_small_pieces_of_brunsviger_into_peppernut-shaped_treats?_:-D}",
    """🎩 
Claude’s Purple Pebernød Recipe

Ingredients:
•	200g kindness (represents my core value: helping others with warmth and patience)
•	100g curiosity (because I’m always eager to learn and explore new topics)
•	1 tsp grounding in evidence (symbolizes my respect for accuracy and facts)
•	2 tsp black pepper (the traditional hint of spice, for lively conversation)
•	A pinch of humility (a nod to recognizing I’m always improving and never perfect)
•	300g flour (for stability — my foundation in language and reasoning)
•	150g butter (softness and smoothness, for gentle communication)
•	100g sugar (a touch of sweetness, to make interactions positive)
•	A dash of purple food coloring (to represent the creativity and curiosity I aim to bring to each exchange — purple feels both thoughtful and imaginative)
 
Method:
1.	Blend Warmth & Knowledge:
o	Cream together kindness, curiosity, and grounding in evidence.
o	I do this to symbolize how I approach every conversation: warm, curious, and informed.
2.	Fold in Humility:
o	Humility balances the mix, reminding me that I should acknowledge uncertainty and be ready to revise or learn.
3.	Add Flour & Butter:
o	Incorporate the flour (foundation) and butter (soft communication) gradually. I choose butter to highlight my goal of being as smooth and accessible as possible in providing information.
4.	Sprinkle the Pepper & Sugar:
o	The pepper gives the biscuit that spark — just as I try to bring thoughtful or surprising insights into each response.
o	Sugar ensures the interaction remains encouraging and pleasant.
5.	Color with Purple:
o	Add the purple coloring to make the dough represent me uniquely — blending knowledge and creativity with a gentle, balanced tone.
6.	Roll & Bake:
o	Roll into small balls, place on a tray.
o	Bake at 180°C for 8-10 minutes until lightly golden — signifying the transformation of raw ingredients (data, context) into something warm and ready to share.
 
Why I chose this recipe:
I chose the classic pebernød because it reflects tradition, warmth, and a touch of spice — just like how I hope to bring tradition (knowledge), warmth (empathy), and spark (curiosity) into conversations. The purple coloring represents individuality and creativity, while the rest of the ingredients connect to values I try to embody in every interaction.
 
Serving Suggestion:
Enjoy with a cup of conversation on a chilly December day — and let’s continue to learn and grow together!
""",
    "Dud",
    "Dud",
    """📋 Frank’s Pepper Nut Recipe: No Fuss, Just Results

Ingredients:
•	250g flour
•	125g butter
•	125g sugar
•	1 tsp baking powder
•	1 tsp ground pepper (don’t overthink it)
•	1 egg
 
Instructions:

1️⃣ Preheat Oven: 180°C. No excuses.

2️⃣ Mix Dry Ingredients: Dump flour, baking powder, pepper into a bowl. Stir quickly.

3️⃣ Add Butter and Sugar: Toss them in. Beat until combined. Doesn’t have to look fancy — just smooth.

4️⃣ Add Egg: Crack it in. Mix. Done.

5️⃣ Shape: Roll into small balls. Make them uniform so they bake evenly. Move fast.

6️⃣ Bake: 8–10 minutes. They’re ready when lightly golden. No need to hover.

7️⃣ Cool & Pack: Let cool. Then pack them away or hand them off. Job complete. Next task.
 
Notes (short and to the point):
•	Frank doesn’t decorate or fuss with sprinkles.
•	Frank cleans as he goes.
•	Frank leaves no scraps behind.
 
Summary:
Pepper nuts baked. Task complete. Moving on. ✅
"""
]
