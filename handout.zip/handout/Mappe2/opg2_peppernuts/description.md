# Peppernuts

**Difficulty:** Easy-Medium  
**Author:** Bond  

New to baking? 🥣🤷 Then start small!💡And it doesn't get much smaller than the traditional Danish Christmas cookie: The *peppernut* 🌰 🎅

I know what you're thinking: *Pepper? In a cookie?! Do they actually do that?!?* Yes, yes we do - but just a small bit 😉 And that little kick is what makes them so good 😋

So give them a try, you might just find your new favorite recipe! 🥇

(**PS:** Your favourite recipe is of course Brunner's recipe 😉)
