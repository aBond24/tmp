# Pretzel

**Difficulty:** Very Hard  
**Author:** Bond  

What is a pretzel 🥨 but intersecting elliptic curves with salt 🧂?
