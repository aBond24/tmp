# So the challenge naturally developed along the way as working in it, and reflecting on what seemed to work 
# and what didn't, or what could be better:
# So some of the things were modified in the final handouts and solution compared to the initial ideas,
# but still using a lot of the same stuff.
# (And hereto some additional details are also contained in e.g. the comments in secret.py .)
# Some main changes were:
# - Now encryption is not ElGamal, but using Sx's to create a symmetric key, 
# which is more real-world resemblance of use anyway, and makes for a simpler hand/out and solution,
# but without making the challenge less interesting, just cleaner and more real-world relevant.
# - And out of the four found curves, only two of them where in fact split-nodal singular curves
# specifically 2 and 4, which are thus the curves used in the final version as 1 and 2 respectively
# (the origianl curve candidates 1 and 3 where non-split nodal, and thus didn't fit so well with the 
# intended "n as the highest prime-factor of p-1"-design.
# - Changed the flag content slightly to have a description fitting more precisely the final curve-selection.
# - And finally revised the handouts and solutions to correspond with the above described. 
# Anyway, the main task of this source script was to design the deliberately insecure curves.
# And the first step in this process, was to find primes p of a seemingly secure size, but with with 
# a small-prime factorizable p-1 making it insecure when a and b parameters simultaneously
# made the curve split-nodal singular:
#-----

# Very fast, and though not proven to always be correct, so far no counter-examples produced: 
from gmpy2 import is_prime 
#Use this additionally if needing to be provenly correct, but not necessary for CTF chall: 
# from sympy import isprime 
from first1000primes import F1000P

def find_p(m: int, n: int=2, i: int=0, PL: tuple[tuple[int]]=[F1000P], a: int=0, c: bool=False) -> int:
    """Starting after the i'th index in in the list of primes P, iteratively multiplies n with the next prime, 
    and returns the first p=n+1 that satisfies p is a prime larger than m.
    - If a%2==1 runs the alternative mode, where post minimum incrementation is done with a second list of of integers instead, 
    - and if a>1 performs the post minimum incrementation with addition rather than multiplicatio,
    - or if a<-1 performs undoes any unsuccesful post minimum incrementation before continuing.
    - If c, then compress mode will continually divide n by 2 to keep it as close as possible to but still above m."""
    P=PL[0]
    while n<m: # No need to check if p is prime until reaching the required minimum value m.
        i+=1; n*=P[i%len(P)]
        print(i)
    P=PL[a%len(PL)]
    while True:
        if c: 
            n2 = n//2
            while n2>m:
                n=n2; n2=n//2
        if is_prime(p:=n+1): 
            return p
        if a<-1: 
            n = n//P[i%len(P)] 
        i+=1
        n = n*P[i%len(P)] if a<2 else n+P[i%len(P)]
        print(i)

# 50 bits to ensure ECC-curve with N~2**50: Thus the ECC encryption can be broken in seconds on a cheap laptop using the algorithm
# Pollard's rho, but will still conversely be impractical to just plain brute-force without the application of such technical insight.  
#M=2**50 
#print(M) # 1125899906842624
#N=find_p(M,M,0,[[2]],2)
# i=27
#print(hex(N)[2:])
# 4000000000037
N = int("4000000000037", 16)

# Start from m to find p's of at least 256-bits for the four curves to superficially seem secure, until the players discover singularity.  
m=2**255
#j=m//2**(N.bit_length()-1)*N
#print(hex(j)[2:])
# 800000000006e000000000000000000000000000000000000000000000000000
j = int("800000000006e000000000000000000000000000000000000000000000000000",16)
#print(j.bit_length()) # 256
SI=list(range(1,2000,2))
def run_find_p(i):
    k=find_p(m, j*SI[i], i, [SI], -2, True)
    print(hex(k)[2:])
    print(k.bit_length())
    return k

#p1=run_find_p(2)
# i=51
p1=int("ce000000000b1080000000000000000000000000000000000000000000000001",16)
# p1.bit_length()=256

#p2=run_find_p(52)
# i=112
p2=int("e1000000000c15c0000000000000000000000000000000000000000000000001",16)
# p.bit_length()=256

#p3=run_find_p(113)
# i=195
p3=int("c3800000000a8020000000000000000000000000000000000000000000000001",16)
# p.bit_length()=256

#p4=run_find_p(196)
# i=238
p4=int("ee800000000ccf60000000000000000000000000000000000000000000000001",16)
# p.bit_length()=256

# So now we have the first parameters for the four curves:
# (using a=-3 and b=2 (both mod p) giving a curve with a double root / intersection, and adding p (no effect mod p) for obfuscation)
p=[p1,p2,p3,p4]
a=[i-3 for i in p]
b=[i+2 for i in p]

# Status of the four curves by now: 
#print(f"""p = {p}\na = {a}\nb = {b}\nq = {[N]*4}""")
"""
p = [93176446808157427656915140589134023458304747128704285515480914392073587654657, 101770390931239908848572362293957064456886252931837205053316532709789112729601, 88427161898032898577315097015416027116983388658551882612992809532283429060609, 107876614387114303379486704031594488324299428107747437356515524672376459493377]
a = [93176446808157427656915140589134023458304747128704285515480914392073587654654, 101770390931239908848572362293957064456886252931837205053316532709789112729598, 88427161898032898577315097015416027116983388658551882612992809532283429060606, 107876614387114303379486704031594488324299428107747437356515524672376459493374]
b = [93176446808157427656915140589134023458304747128704285515480914392073587654659, 101770390931239908848572362293957064456886252931837205053316532709789112729603, 88427161898032898577315097015416027116983388658551882612992809532283429060611, 107876614387114303379486704031594488324299428107747437356515524672376459493379]
q = [1125899906842679, 1125899906842679, 1125899906842679, 1125899906842679]
"""
# Now if we test which of these candidate curves actually turned out split-nodal,
# we see that 2 and 4 did, while 1 and 3 turned out non-split nodal.
# - So 2 and 4 are the two curves that we will use for the challenge
# (where they will then be called 1 and 2).


# Now to find a point on each curve to use for g, we use the code in generateG.py, which does the following:
# Since the curves are singular with double root, they each form multiplicative groups of order q equal to 
# the highest prime-factor, thus by intended design from above: q=[N]*4. And since all the other primefactors 
# of p-1 are very small, this allows us to choose G's that are primitive factors of p-1, i.e. have order
# equal to p-1, without this increasing the hardware demands of the challenge in any significant way, 
# as the demanding bottleneck is still only the Pollard-rho step on the large prime factor.

# Thus, we can thereby create curves with n close to p, and still use the same mechanics and solutions 
# script and flag and originally designet for the earlier challenge version with n=q, but:
# The new data improves educational value, realism, and difficulty (but only in a interesting and 
# relevant way) of the challenge. (- Also especially since the Pohlig-Hellman and CRT step 3 now is actually
# indispensable rather than more as earlier just a formality.)

# Thus summing up: 
# - Better values for a more educational, interesting, and slightly more difficult challenge. 
# - But the same solution scrip and description as the former version

# PS: And by the way on the topic of the solution: Yes the CRT part in step four just before getting 
# the flag ís technically redundant: 
# - The two p's are different and thus so are the two n's = p's - 1
# - but, the k was the same for both curves, k<min(n_1,n_2)
# - but if the players do not take this for granted that final CRT could still in principle be needed 
# - but in either case it verifies the per-curve residues agree modulo gcd(n_1,n_2) 
# - thus keeping things transparent, serving as a harmless consistency check, and showcasing a general method. 

# PPS: Maybe it would be even more interesting if only one of the curves was insecure?!:
# The solve current works well with curve 1. But to set up for anticipation, let's move that weak curve
# to slot two instead, and have a not weak enough curve at slot one, same curve concept except now 
# it will be a curve with a large p-1 prime factor too large to deal with. 

# For example 200 bit prime should be rather unmanagable.  
#M=2**200 
#print(M) # 1125899906842624
#N=find_p(M,M,0,[[2]],2)
# i=117
#print(hex(N)[2:])
# 1000000000000000000000000000000000000000000000000eb
N = int("1000000000000000000000000000000000000000000000000eb", 16)

# Start from m to find p's of at least 256-bits for the four curves to superficially seem secure, until the players discover singularity.  
m=2**255
#j=m//2**(N.bit_length()-1)*N
#print(hex(j)[2:])
# 8000000000000000000000000000000000000000000000007580000000000000
j = int("8000000000000000000000000000000000000000000000007580000000000000",16)
#print(j.bit_length()) # 256

#p1=run_find_p(2)
# i=100
p1=int("c90000000000000000000000000000000000000000000000b883000000000001",16)
# p1.bit_length()=256

#p2=run_find_p(101)
# i=217
p2=int("d98000000000000000000000000000000000000000000000c7a8800000000001",16)
# p.bit_length()=256

#p3=run_find_p(218)
# i=277
p3=int("8ac0000000000000000000000000000000000000000000007f5e400000000001",16)
# p.bit_length()=256

#p4=run_find_p(278)
# i=314
p4=int("9d40000000000000000000000000000000000000000000009059c00000000001",16)
# p.bit_length()=256

# So now we have the first parameters for the four curves:
# (using a=-3 and b=2 (both mod p) giving a curve with a double root / intersection, and adding p (no effect mod p) for obfuscation)
p=[p1,p2,p3,p4]
a=[i-3 for i in p]
b=[i+2 for i in p]

# Status of the four curves by now: 
#print(f"""p = {p}\na = {a}\nb = {b}\nq = {[N]*4}""")
"""
p = [90914882565236544063038156198227615150419011397631849109118664164237971030017, 98378044566860439471198004841365702961274303378034463588225420177720192532481, 62758407740928211386798727226388465682192228017021985392488630113373226270721, 71126195439718639571705224189906927773151191752624916778153780795156323106817]
a = [90914882565236544063038156198227615150419011397631849109118664164237971030014, 98378044566860439471198004841365702961274303378034463588225420177720192532478, 62758407740928211386798727226388465682192228017021985392488630113373226270718, 71126195439718639571705224189906927773151191752624916778153780795156323106814]
b = [90914882565236544063038156198227615150419011397631849109118664164237971030019, 98378044566860439471198004841365702961274303378034463588225420177720192532483, 62758407740928211386798727226388465682192228017021985392488630113373226270723, 71126195439718639571705224189906927773151191752624916778153780795156323106819]
q = [1606938044258990275541962092341162602522202993782792835301611, 1606938044258990275541962092341162602522202993782792835301611, 1606938044258990275541962092341162602522202993782792835301611, 1606938044258990275541962092341162602522202993782792835301611]
"""
# Now if we test which of these candidate curves actually turned out split-nodal,
# we see that 1-3 did, while 4 turned out non-split nodal.
# - So 1 will just be the curve that we will use for the challenge
# (where after the prior 1 moved to slot 2, this new 1 will now also be called 1 in the chall).
