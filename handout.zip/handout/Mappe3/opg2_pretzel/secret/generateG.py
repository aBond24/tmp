from random import randrange
from sympy import factorint
from sympy.ntheory.residue_ntheory import sqrt_mod

def find_alpha(a,b,p):
    t = (-a * pow(3, -1, p)) % p
    r = sqrt_mod(t, p, all_roots=False)
    if r is None: return None
    for u in (r, (-r) % p):
        if (pow(u,3,p) + a*u + b) % p == 0:
            return u
    return None

def lift_u_to_point(u, p, a, b, alpha, r):
    # s = r*(1+u)/(1-u) ; x = s^2 - 2α ; y = s*(s^2 - 3α)
    s = (r * (1 + u) * pow((1 - u) % p, -1, p)) % p
    x = (s*s - 2*alpha) % p
    y = (s*(s*s - 3*alpha)) % p
    # quick sanity (optional):
    assert (y*y - (x*x*x + a*x + b)) % p == 0
    return (x, y)

def sample_primitive_u(p):
    fac = factorint(p-1)
    while True:
        u = randrange(2, p)          # in F_p^*
        if all(pow(u, (p-1)//ell, p) != 1 for ell in fac):  # primitive test
            return u

def make_primitive_G(a, b, p):
    alpha = find_alpha(a,b,p)
    r = sqrt_mod((3*alpha) % p, p, all_roots=False)  # split-node check assumed true
    u  = sample_primitive_u(p)
    return lift_u_to_point(u, p, a, b, alpha, r)     # returns G with ord(u(G)) = p-1

from handouts import a_list, b_list, p_list, inv

#G_list = [make_primitive_G(a,b,p) for a, b, p in zip(a_list, b_list, p_list)]; print(G_list)
G_list = [(31050621188682335241371326692276113333037865262574375461832507815231354661108, 
     55368851359349074519270007940435891631334772844860139655892860934285057401271), 
    (42588099604299172563555389284269876930484458686346414575256244246451517913988, 
     92018355397681073752377324460550882831430130854004599311301976509793681162305)]

def s_param(P,p,alpha,inv):
    x,y = P; den = (x - alpha) % p
    return (y * inv(den, p)) % p

def u_map(P,p,alpha,r,inv):
    s = s_param(P,p,alpha,inv); den = (s + r) % p
    return ((s - r) * inv(den, p)) % p

def is_primitive_via_u(G, a, b, p, inv):
    alpha = find_alpha(a,b,p)
    r = sqrt_mod((3*alpha) % p, p, all_roots=False)   # split case
    uG = u_map(G, p, alpha, r, inv)                   # in F_p^*
    fac = factorint(p-1)                              # p-1 = ∏ ℓ^{e_ℓ}
    # Primitive iff uG^((p-1)/ℓ) != 1 for all prime ℓ | p-1
    return all(pow(uG, (p-1)//ell, p) != 1 for ell in fac)

for a, b, p, G in zip(a_list, b_list, p_list, G_list):
    print(is_primitive_via_u(G,a,b,p,inv))
#True
#True
