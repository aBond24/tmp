# Normally b and n are public, but here chosen secrets, to increase the difficulty of the challenge.
# This is to make the solution less obvious, but still achievable, 
# since the players can derived the values from the available information in the handouts:

# b % p can be found since b is the only missing value in: y**2 % p = (x**3 % p + a*x % p + b % p) % p
# (b%p is the value that is actually relevant, and thus the b+p shown below was just for obfuscation, 
# to make the singularity of the curves less obvious, if the b as originally intended had been shown.)
b_list = [
    101770390931239908848572362293957064456886252931837205053316532709789112729603,
    107876614387114303379486704031594488324299428107747437356515524672376459493379
]
# (NB: Potentially also somewhat interpretable in line with the description of "intersecting curves",
# b%p is 2 for all the curves.)

# Now with b%p also known, the players can identify that the curves are split nodal, 
# and thus worst case n is the largest prime factor of p-1. And prime-factorizing p-1,
# they can find n to be the following:
from public import p_list
#n_list = [p-1 for p in p_list]; print(n_list)
n_list = [101770390931239908848572362293957064456886252931837205053316532709789112729600, 
          107876614387114303379486704031594488324299428107747437356515524672376459493376]


# Now neither b nor n are needed for running the handout script pretzel.py, 
# and thus the only constants imported by that script are:  

# Secrets: 
# (NB: Here again also potentially somewhat interpretable in line with the description of 
# "intersecting curves", d and k are chosen commonly for both the curves, however thus necessitating
# that they both be upperbound by the lowest n of the curves:)
#n = min(n_list); print(n)
n = 101770390931239908848572362293957064456886252931837205053316532709789112729600
from secrets import randbelow as r
#d = 1 + r(n-1); print(d)
d = 39803553263017893333433028413261779074691728855275600152989147735907593358849 # private key
#k = 1 + r(n-1); print(k)
k = 45113309632402963069012670848434296870884528838894182786305892449810929701952 # ephemeral
flag = 'brunner{1F_y0u_9iVe_4n_El1IpTiC_cUrve_4_SPl17_N0dE,_A5_a_tRaNsV3rSE_5eLf-In7Er5ectiOn,_4nD_A_6ad_P,_i7_6EComeS_Ins3cUrE_:)}'
