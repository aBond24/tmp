# Making a pretzel is fairly simple in principle, but hard to master - unless you know how ;-)

from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from public import p_list, a_list, looks_done
from secret import d, flag
from handouts import R_list


# However basically it's just about the following: 

# 1) The key to a good pretzel is the dough:
dough = b''

# 2) And the dough is shaped into specific curves of the general shape:
# y**2 % p = (x**3 % p + a*x % p + b % p) % p

def mul(k,P,p,a):
    R=None; A=P
    while k:
        if k&1: R=add(R,A,p,a)
        A=add(A,A,p,a)
        k>>=1
    return R

def add(P,Q,p,a):
    if P is None: 
        return Q
    if Q is None: 
        return P
    x1,y1=P; x2,y2=Q
    if x1==x2 and (y1+y2)%p==0: 
        return None
    if P==Q:
        slope=(3*x1*x1+a)*inv((2*y1)%p,p)%p
    else:
        slope=(y2-y1)*inv((x2-x1)%p,p)%p
    x3=(slope*slope-x1-x2)%p
    y3=(slope*(x1-x3)-y1)%p
    return (x3,y3)

def inv(x,p): 
    return pow(x,p-2,p)

# 3) And those shaped curves of dough are baked in the oven: 
def unbake(R,p,a):
    Sx=mul(d,R,p,a)[0]
    return Sx

# 4) And look for the colour, to see when they are done:
colour = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    # Remember to sprinkle with salt, to make it a pretzel :)
    salt=b'pretzelsalt-sprinkle_for_the_win',
    info=b'pretzelbaking'
)

# And voila! Here's your pretzel: :)
for p, a, R in zip(p_list, a_list, R_list):
    Sx = unbake(R, p, a)
    print(Sx)
    dough+=Sx.to_bytes((Sx.bit_length() + 7) // 8, 'big')

plain_text = (AESGCM(colour.derive(dough)).decrypt(b'pretzelnonce', bytes.fromhex(looks_done), None)).decode()
found_flag = 'brunner{' + plain_text + '}'
print(found_flag)
assert found_flag == flag
