# As described in the solution and general readme, 
# the cheese of this challenge was to have 
# an obfuscated decryption function, that could seem 
# to be taking encrypted data as input, 
# and applying a key hardcoded in the function definition, 
# when in fact rather the data was in the definition, 
# and the input was the key. 
# - The intermediate computations used in the process 
# of deriving the concrete values to be hardcoded, 
# is given in the following:

flag = "brunner{7Urn5_0uT_th3Re_WasN7_4nY_SEcr3T5_4FtR_A1l_x)_Badum-tss}"
#print(len(flag)) # 64
f = flag.encode('utf-8')
#print(f.hex())
# 6272756e6e65727b3755726e355f3075545f74683352655f5761734e375f346e595f534563723354355f344674525f41316c5f78295f426164756d2d7473737d

target = "8350e5a3e24c153df2275c9f80692773"
t = bytes(int(b,16) for b in target).hex().encode()
#print(len(t.hex())) # 128
#print(t.hex())
# 30383033303530303065303530613033306530323034306330313035303330643066303230323037303530633039306630383030303630393032303730373033

code = bytes(x ^ y for x, y in zip(f, t))
#print(code.hex())
# 524a455d5e50424b0730425b053e0046643a445a0366553c6750437b076c040a6939637753400363056a0425446b6f2701546f481969725854475d1a4444434e

code1_2 = "524a455d5e50424b0730425b053e0046643a445a0366553c6750437b076c040a"
code2_2 = "6939637753400363056a0425446b6f2701546f481969725854475d1a4444434e"
d = (int(code2_2, 16) - int(code1_2, 16)) // 2
c = int(code1_2, 16) + d
#print(c, d)
# 42407562439075681492143456259122041922599228616502828873021088919446915392428 
# 5186683434748896574370264474720365034728611610795088756404643529414136307618
#print((c-d).to_bytes(32, 'big').hex()==code1_2)
#print((c+d).to_bytes(32, 'big').hex()==code2_2)

# If there is really cheese in this cake, it should be flagged!
def get_FLAG_from_HEX(hexcode):
    """Input the hexadecimal code string of sufficient length to remove obfuscation and return 
    the decrypted flag as a plaintext string starting with 'brunner{' and ending with '}'."""
    assert len(hexcode) % 32 == 0
    bytes_data = bytes(int(b,16) for b in hexcode).hex().encode()
    c = 42407562439075681492143456259122041922599228616502828873021088919446915392428 
    d = 5186683434748896574370264474720365034728611610795088756404643529414136307618
    plaintext = SPECIAL_technique(bytes_data, c, d)
    return plaintext.decode()

# There's a special cooking technique that we'll be using a lot for this recipe. 
def SPECIAL_technique(bytes_data, c, d):
    """Combines the integers c and d in interchanging ways, and xors the values with the bytes_data."""
    xor_bytes = bytearray()
    for i in range(0, len(bytes_data)//32):
        block = bytes_data[i*32:(i+1)*32]
        xor_bytes.extend(x ^ y for x, y in zip(block, (c - (-1)**i * d).to_bytes(32, 'big')))
    return xor_bytes

#print(get_FLAG_from_HEX(target))
# brunner{7Urn5_0uT_th3Re_WasN7_4nY_SEcr3T5_4FtR_A1l_x)_Badum-tss}


# Using the same technique now for the solution_readmetext:

#from recipe import *; flag = get_FLAG_from_HEX(hex); print(flag)
# brunner{7Urn5_0uT_th3Re_WasN7_4nY_SEcr3T5_4FtR_A1l_x)_Badum-tss}
solution = 'from recipe import *; print("flag =  " + get_FLAG_from_HEX(hex))'
#print(len(solution))  # 64
s = solution.encode('utf-8')
#print(s.hex())
# 66726f6d2072656369706520696d706f7274202a3b20666c6167203d206765745f464c41475f66726f6d5f48455828686578293b207072696e7428666c616729
 
ciphertext = "4587a73dc7ef709fcbddd7d2ac49aa441c52d31d7ba2aa44865e5c3eb0fabc01ce636904a491d48a3cb5565fa5ed3b0cac9b6e3fcb2facf7efc4791e63df131b45a10e182f6963a51e4730014d7cfa6954aa8e75bbb2db34ceeddabab4ed033acd364a51a2a2f58fac906926313810e4a694f5feae66a81c8dac4da984641229" 
target = "4587a73dc7ef709fcbddd7d2ac49aa441c52d31d7ba2aa44865e5c3eb0fabc01ce636904a491d48a3cb5565fa5ed3b0cac9b6e3fcb2facf7efc4791e63df131b"
t = bytes.fromhex(target)

code = bytes(x ^ y for x, y in zip(s, t))
#print(code.hex())
# 23f5c850e79d15fca2adb2f2c524da2b6e26f3374082da36ef302816929cd060a943542484b3f4a11cd2332bfaab774debc4084da442f3bfaa9c517606a73a32

code1_2 = "23f5c850e79d15fca2adb2f2c524da2b6e26f3374082da36ef302816929cd060"
code2_2 = "a943542484b3f4a11cd2332bfaab774debc4084da442f3bfaa9c517606a73a32"
d = (int(code2_2, 16) - int(code1_2, 16)) // 2
c = int(code1_2, 16) + d
#print(c, d)
# 46412520328440256871399753615737168429362885041489783567894921161800073479497
# 30147310566698376871947829873776459834598978229983782629303180618977163687145
#print((c-d).to_bytes(32, 'big').hex()==code1_2)
#print((c+d).to_bytes(32, 'big').hex()==code2_2)

# If you're in an experimental mood, you could try mixing beaten egg with milk and sugar to pour over 
# the crackers as an added solution giving breadtexture to the crust.   
def ADDed_SOLUTION_giving_bREADMETEXTure(ciphertext, e):
    """Splits a 128 byte ciphertext into two blocks and xors them with values, which besides serving as 
    further encryption intermediately also turns the first block into bytes that if decoded contains 
    plaintext describing in full detail how to get the flag in this challenge."""
    assert len(ciphertext) == 128
    c = 46412520328440256871399753615737168429362885041489783567894921161800073479497
    d = 30147310566698376871947829873776459834598978229983782629303180618977163687145
    solution_readmetext = SPECIAL_technique(ciphertext[:64], c, d)
    residual_ciphertext = SPECIAL_technique(ciphertext[64:], c, d)
    ciphertext = bytes(b ^ e for b in (solution_readmetext + residual_ciphertext))
    return ciphertext

#print(ADDed_SOLUTION_giving_bREADMETEXTure(bytes.fromhex(ciphertext), 0)[:64].decode())
#from recipe import *; print("flag =  " + get_FLAG_from_HEX(hex))


# And finally, to find the values for the INTEGER encryption function, 
# to ensure that the MD2 hash function receives an empty string as input:

ciphertext_in_hex = '0f2448fab60f6a31fa6bbdec5fe76969ea7ba558f1f12efb1e83e5f4210e9863dca2b99e8d4a94be79c6bac54ec37857c31c7d2031739ba36cd6682d2ca42ea6b627de9086f580e2410228cd1e475925aa85eeb8bfd7ce8bc117e55bb8b1f95a56d5801db1b55db99a131db21e7641c2fba6ae67f288128ba660d81b8ef16f56'
k = int(ciphertext_in_hex, 16)*4+1
#print(k) # 42531561700949164591929290343028063836413903274743744847079187883040710563899682232700778999894155244171997722786759461874731727436943745636566887022052288987524095199970119808016287810401677527722608438915831254645051638466662710210688468783135525152216244966516274236169823786694404719918311222719935790425
#print('0'+hex(k//4)[2:]==ciphertext_in_hex) # True
d=[chr(i)for i in range(32,127)]
b=len(d)
s2i=lambda s:sum(d.index(c)*b**i for i,c in enumerate(s[::-1]))
def i2s(n):
    if n == 0: return d[0]
    r = []
    while n > 0:
        n, rem = divmod(n, b)
        r.append(d[rem])
    return ''.join(reversed(r))
test = i2s(k)
#print(test) # """,&6y5jz*r~6BR `|FQ39*So7w`,&oC*1^PZhCKp}UT. C^tgoVBRb$z`*Zpa)XB>|b^%MO~6~IR_whvM!}|mA |@jj090!*gP;?Qf*Cj0$"{@5&[HjpVTnig|>?]Q$CT4}{S3i8iC[kUq2GfW3\>iu:O30qp"""
#print(s2i(test)==k) # True

# After adding several different things it's a good time to beat the ingredients together.
def beat_INTEGERgredients(ciphertext, int_key):
    """Uses operation with large integers (and base-95 for concise storage) to return the ciphertext 
    after modifying it with, using an int_key that is security wise - as usual by now - super insecure."""
    s = """,&6y5jz*r~6BR `|FQ39*So7w`,&oC*1^PZhCKp}UT. C^tgoVBRb$z`*Zpa)XB>|b^%MO~6~IR_whvM!}|mA |@jj090!*gP;?Qf*Cj0$"{@5&[HjpVTnig|>?]Q$CT4}{S3i8iC[kUq2GfW3\\>iu:O30qp"""
    s2i = lambda s:sum((d:=[chr(i) for i in range(32,127)]).index(c)*len(d)**i for i,c in enumerate(s[::-1]))
    i = s2i(s)//int_key
    n = int.from_bytes(ciphertext, 'big')
    ciphertext = (m:=n-i).to_bytes((m.bit_length() + 7) // 8, 'big')
    return ciphertext

test = bytes.fromhex(ciphertext_in_hex)
#print(len(beat_INTEGERgredients(test, 4))) # 0


# And that was it, for the calculations of the special values. - See recipe.py for the rest ;-)
