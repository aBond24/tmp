# Cheesecake

**Difficulty:** 🧀  
**Author:** Bond  

Whoever thought 💡 of mixing 👀 cheese 🧀 with cake 🧁 it sure is easy on the palate 😋
