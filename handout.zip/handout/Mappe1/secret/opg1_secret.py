plaintext = "HERE IS THE PLAINTEXT"
key = 2
