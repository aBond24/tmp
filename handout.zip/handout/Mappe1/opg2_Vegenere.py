from opg2_secret import plaintext, key
alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

i=0
ciphertext = ""
for char in plaintext:
    # If sætnigen her betyder, at alt der ikke er et stort bogstav, forbliver uændret.
    if char in alphabet:
        ciphertext += alphabet[(alphabet.index(char) + alphabet.index(key[i % len(key)])) % len(alphabet)]
        i += 1
    else:
        ciphertext += char

assert ciphertext == "GBUT XZZY YBOV GBQ QPRVHFFBK YIZHII NHP HIK GBQ DLRAWQ US WVHP MIKGYD QEKGYDOW ZA NTF GZCBQSXVKN TFVV GBMU VVCYMU FVPUGTI JBGQUMDRM FII JNGQ XSIQ ID QEIG IR B AFEX MQTVNLE BX DBLQ ULRA IZF TFFCFJSE JBQSI KUY EBQV YYFUIIF ZDPQ KUY WFC REY GTIU VH FII VAWDZTKVIZ"
