from opg1_secret import plaintext, key
alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

ciphertext = ""
for char in plaintext:
    # If sætnigen her betyder, at alt der ikke er et stort bogstav, forbliver uændret.
    if char in alphabet:
        ciphertext += alphabet[(alphabet.index(char) + key) % len(alphabet)]
    else:
        ciphertext += char

assert ciphertext == "JGTG KU VJG RNCKPVGZV"
