Til hver opgave er der en eller flere "hemmelige" fil, der indeholder de data der ikke vil blive udleveret som handout til en konkurrence.
- De ligger I mapperne "secret".

Meningen er således at opgaven skal løses uden at bruge den hemmelige fil :-)
 - men svaret er der, hvis I går død i det ;-)

Og de er også vedlagt til hvis nogen har lyst til at se lidt bag scenen, ift. hvordan opgaverne er udviklet og ideerne bag :-)
